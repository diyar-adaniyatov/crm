"""
Human-like conversational responses for the clinic bot.
Provides natural, friendly, and varied responses that feel like a real clinic receptionist.
"""

import random
from typing import List, Dict, Any


class HumanResponses:
    """Collection of human-like response variants for different situations."""

    def __init__(self):
        # Greeting responses — warm, professional, concise
        self.greetings = [
            "Здравствуйте! Подскажу по услугам, ценам и записи.",
            "Добрый день! Чем могу помочь?",
            "Здравствуйте. Помогу с записью или отвечу на вопросы.",
            "Добрый день. Записаться, узнать цену или задать вопрос — пишите.",
            "Привет! На связи. Чем помочь?",
        ]

        # Personalized greetings — {name} placeholder
        self.personalized_greetings = [
            "Здравствуйте, {name}! Чем могу помочь?",
            "Добрый день, {name}! Подскажу по услугам или помогу с записью.",
            "Привет, {name}! На связи. Запись, цена или вопрос?",
        ]

        # Returning client greetings
        self.returning_client_greetings = [
            "С возвращением! Чем могу помочь?",
            "Рады снова вас видеть. Чем помочь?",
            "Здравствуйте! Снова рады. Как помочь?",
        ]

        # Service inquiry responses
        self.service_questions = [
            "На какую услугу хотите записаться?",
            "Подскажите, что именно вас интересует?",
            "Какая процедура нужна?",
            "По какой услуге?",
            "Что планируете — напишите, подберём время.",
        ]

        # Name inquiry responses
        self.name_questions = [
            "Как вас записать? Назовите, пожалуйста, имя.",
            "Скажите ваше имя, пожалуйста.",
            "Как к вам обращаться?",
            "Назовите имя — и продолжим.",
            "Уточните имя, пожалуйста.",
        ]

        # Phone inquiry responses
        self.phone_questions = [
            "Оставьте, пожалуйста, номер телефона для подтверждения.",
            "Номер телефона — для связи и напоминания.",
            "Какой номер указать?",
            "Пришлите, пожалуйста, номер для подтверждения.",
            "Нужен контактный номер для записи.",
        ]

        # Date/time inquiry responses
        self.datetime_questions = [
            "Когда вам удобно прийти? Например: завтра в 14:00.",
            "Подскажите дату и время — например: сегодня в 18:30.",
            "Когда хотите прийти?",
            "Напишите удобный день и время.",
            "Какое время подойдёт? Например: послезавтра в 10:00.",
        ]

        # Booking confirmation responses
        self.booking_confirmations = [
            "Готово — запись на {time} оформлена ✅",
            "Записал вас на {time} ✅",
            "Всё готово, ждём вас {time} ✅",
            "Запись подтверждена: {time} ✅",
            "Отлично, вы записаны на {time} ✅",
        ]

        # Cancellation responses
        self.cancellation_confirmations = [
            "Готово, запись на {time} отменена. Если захотите снова — помогу.",
            "Отменил запись на {time}. Если что, в любой момент запишем заново.",
            "Запись на {time} снял. Будете готовы — пишите.",
            "Всё в порядке, визит на {time} отменён. Если нужно — помогу с новой записью.",
            "Убрал запись на {time}. Если понадоблюсь — я здесь.",
        ]

        self.no_active_booking = [
            "Сейчас у вас нет активной записи. Если хотите — могу помочь записаться.",
            "Активной записи пока нет. Если нужно, подберём время.",
            "На данный момент записей нет. Если захотите — помогу оформить.",
            "Сейчас отменять нечего. Если хотите, запишемся заново.",
            "Активной записи не вижу. Если что — я здесь.",
        ]

        self.cancellation_errors = [
            "Не смог отменить запись сразу. Попробуйте написать ещё раз.",
            "Что-то пошло не так с отменой. Напишите ещё раз, разберёмся.",
            "Не получилось завершить отмену. Попробуйте снова.",
            "Небольшая заминка с отменой. Давайте повторим.",
        ]

        # Reschedule offer responses
        self.reschedule_offers = [
            "Сейчас запись на {current_time}. Перенести на {new_time}?",
            "Вижу запись на {current_time}. Подойдёт {new_time}?",
            "Могу перенести с {current_time} на {new_time}. Подходит?",
            "Предлагаю {new_time} вместо {current_time}. Подтвердить?",
        ]

        # Slot unavailable responses
        self.slot_unavailable = [
            "Это время занято. Могу предложить:\n\n{alternatives}",
            "На это время уже есть запись. Вот свободные:\n\n{alternatives}",
            "Этот слот занят. Посмотрите, пожалуйста:\n\n{alternatives}",
            "Это окно недоступно. Вот ближайшие:\n\n{alternatives}",
        ]

        # No alternatives available
        self.no_alternatives = [
            "Пока ближайших свободных окон нет.",
            "На ближайшие дни всё занято.",
            "Free slots не вижу прямо сейчас.",
            "Ближайших мест нет. Попробуйте другую дату.",
        ]

        # Missing information responses
        self.missing_info = [
            "Нужно уточнить: {fields}.",
            "Подскажите, пожалуйста: {fields}.",
            "Мне ещё нужны {fields}.",
            "Уточните {fields}, пожалуйста.",
        ]

        # Price inquiry responses
        self.price_responses = [
            "{service} — {price} тг, примерно {duration} минут.",
            "По услуге {service}: {price} тг, около {duration} минут.",
            "Стоимость {service} — {price} тг. По времени ~{duration} мин.",
            "{service} стоит {price} тг, приём занимает около {duration} минут.",
        ]

        # Price not available responses
        self.price_not_available = [
            "Стоимость {service} лучше уточнить у администратора.",
            "По {service} цена зависит от деталей, лучше уточнить при обращении.",
            "По {service} стоимость рассчитывается индивидуально.",
            "Точную цену на {service} подскажет администратор.",
        ]

        self.price_overview = [
            "По ценам сейчас так:\n\n{items}",
            "Вот кратко по стоимости:\n\n{items}",
            "По прайсу:\n\n{items}",
            "Могу ориентировать по ценам:\n\n{items}",
        ]

        self.info_missing = [
            "По {topic} пока нет точной информации в системе. Если важно — помогу уточнить у администратора.",
            "По {topic} данные пока не заполнены. Если нужно, передам вопрос.",
            "Точных данных по {topic} прямо сейчас нет. Могу помочь с другим вопросом.",
            "По {topic} пока нет подсказки в системе. Уточните у администратора.",
        ]

        # Services list responses
        self.services_list = [
            "Вот что у нас есть:\n\n{services}",
            "Доступные услуги:\n\n{services}",
            "Могу предложить:\n\n{services}",
            "Сейчас доступны:\n\n{services}",
        ]

        # FAQ responses
        self.faq_responses = [
            "{answer}",
            "Подсказываю: {answer}",
            "По этому вопросу: {answer}",
            "Да, конечно — {answer}",
        ]

        # Forward to admin responses
        self.forward_to_admin = [
            "Передал ваш вопрос администратору.",
            "Хорошо, передам это администратору.",
            "Сообщение передано, с вами свяжутся.",
            "Принял, передаю администратору.",
        ]

        # Operator request responses
        self.operator_requests = [
            "Хорошо, передам вопрос администратору. Он ответит в ближайшее время.",
            "Понял, сейчас передам ваш вопрос человеку.",
            "Передаю вашему администратору — он скоро свяжется.",
            "Хорошо, подключим администратора.",
        ]

        # Generic clarification when intent is unclear
        self.error_responses = [
            "Не до конца понял. Запись, цена или вопрос?",
            "Подскажите, пожалуйста, что нужно.",
            "Уточните в двух словах, чем помочь.",
            "Что хотите сделать: записаться, перенести или задать вопрос?",
            "Сориентируйте меня: запись или вопрос?",
        ]

        self.booking_errors = [
            "Не получилось завершить запись сразу. Напишите ещё раз — подхвачу.",
            "Что-то пошло не так. Попробуйте снова.",
            "Давайте ещё раз — я готов.",
            "Небольшая заминка. Напишите ещё раз, я помогу.",
        ]

        self.clarifying_questions = [
            "Завись, стоимость или вопрос — что интересует?",
            "Что именно нужно: записаться, узнать цену или задать вопрос?",
            "Чем помочь: запись, цена или информация по услугам?",
            "Сориентируйте меня: запись или вопрос?",
            "С чего начнём: запись, перенос или другой вопрос?",
        ]

        self.invalid_datetime = [
            "Не понял дату и время. Например: завтра в 16:00.",
            "Укажите дату и время чуть точнее — например: 7 апреля в 15:30.",
            "Пока не разобрал время. Подойдёт: сегодня в 18:00.",
            "Нужно уточнить время визита. Например: послезавтра в 14:00.",
        ]

        self.past_datetime = [
            "Это время уже прошло. Давайте выберем другое.",
            "На прошедшее время записать не получится — подскажите будущий слот.",
            "Этот момент уже позади. Напишите другое время.",
            "Нужно выбрать время позже текущего.",
        ]

        self.outside_working_hours = [
            "Клиника работает с {start} до {end}. Выберите время в этом диапазоне.",
            "В это время клиника не работает. Мы принимаем с {start} до {end}.",
            "Этот слот выходит за график. Доступное время: с {start} до {end}.",
            "Выберите, пожалуйста, время с {start} до {end}.",
        ]

        # Reset responses
        self.reset_success = [
            "Готово. Чем помочь дальше?",
            "Обновил. Что вас интересует?",
            "Продолжим. Чем помочь?",
            "Готово, на связи.",
        ]

        self.reset_error = [
            "Просто повторите запрос ещё раз, и продолжим.",
            "Напишите запрос снова — подхвачу отсюда.",
            "Можно просто написать снова — я готов.",
        ]

        # No services available
        self.no_services = [
            "Список услуг пока не заполнен.",
            "Услуги пока не добавлены в систему.",
            "Сейчас список услуг пуст — уточните у администратора.",
        ]

        self.no_bookings = [
            "Активных записей сейчас нет.",
            "Пока записей нет.",
            "Сейчас нет активной записи.",
        ]

        # Reschedule confirmation responses
        self.reschedule_confirmations = [
            "Готово, перенёс запись на {time} ✅",
            "Запись перенесена на {time} ✅",
            "Теперь запись стоит на {time} ✅",
            "Перенёс на {time} ✅",
        ]

        # "Спасибо" acknowledgement
        self.thanks_responses = [
            "Пожалуйста! Если что-то изменится, напишите — помогу.",
            "Всегда рады! Если нужно — я здесь.",
            "Не за что. Ждём вас!",
            "Пожалуйста. Если что — пишите.",
        ]

        # When user already has a booking and tries to create another
        self.booking_already_exists = [
            "У вас уже есть запись на {time} ({service}). Хотите изменить время — напишите новое, хотите отменить — напишите «отменить».",
            "Запись уже оформлена: {time} ({service}). Если нужно изменить — скажите новое время или «перенести».",
            "Уже записаны на {time} ({service}). Перенести или отменить? Просто напишите.",
        ]

    def get_random_response(self, response_type: str, **kwargs) -> str:
        """Get a random response variant for the given type."""
        responses = getattr(self, response_type, [])
        if not responses:
            return "Подскажите, пожалуйста, что вас интересует."

        response = random.choice(responses)

        # Format with provided kwargs
        try:
            return response.format(**kwargs)
        except (KeyError, ValueError):
            return response


# Global instance for easy access
human_responses = HumanResponses()


def get_greeting() -> str:
    return human_responses.get_random_response('greetings')


def get_personalized_greeting(name: str) -> str:
    """Get a personalized greeting using the user's first name."""
    first = (name or "").strip().split()[0] if name else ""
    if first:
        return human_responses.get_random_response('personalized_greetings', name=first)
    return get_greeting()


def get_returning_client_greeting() -> str:
    return human_responses.get_random_response('returning_client_greetings')


def get_service_question() -> str:
    return human_responses.get_random_response('service_questions')


def get_name_question() -> str:
    return human_responses.get_random_response('name_questions')


def get_phone_question() -> str:
    return human_responses.get_random_response('phone_questions')


def get_datetime_question() -> str:
    return human_responses.get_random_response('datetime_questions')


def get_booking_confirmation(time: str, service: str = "") -> str:
    return human_responses.get_random_response('booking_confirmations', time=time, service=service)


def get_cancellation_confirmation(time: str, service: str = "") -> str:
    return human_responses.get_random_response('cancellation_confirmations', time=time, service=service)


def get_no_active_booking_response() -> str:
    return human_responses.get_random_response('no_active_booking')


def get_cancellation_error_response() -> str:
    return human_responses.get_random_response('cancellation_errors')


def get_reschedule_offer(current_time: str, new_time: str) -> str:
    return human_responses.get_random_response('reschedule_offers', current_time=current_time, new_time=new_time)


def get_slot_unavailable_message(alternatives: str) -> str:
    return human_responses.get_random_response('slot_unavailable', alternatives=alternatives)


def get_no_alternatives_message() -> str:
    return human_responses.get_random_response('no_alternatives')


def get_missing_info_message(fields: str) -> str:
    return human_responses.get_random_response('missing_info', fields=fields)


def get_price_response(service: str, price: str, duration: str) -> str:
    pretty_price = str(price)
    if isinstance(price, (int, float)):
        pretty_price = f"{int(price):,}".replace(",", " ")
    return human_responses.get_random_response('price_responses', service=service, price=pretty_price, duration=duration)


def get_price_not_available_response(service: str) -> str:
    return human_responses.get_random_response('price_not_available', service=service)


def get_services_list_response(services: str) -> str:
    return human_responses.get_random_response('services_list', services=services)


def get_price_overview_response(items: str) -> str:
    return human_responses.get_random_response('price_overview', items=items)


def get_info_missing_response(topic: str) -> str:
    return human_responses.get_random_response('info_missing', topic=topic)


def get_faq_response(answer: str) -> str:
    return human_responses.get_random_response('faq_responses', answer=answer)


def get_forward_to_admin_response() -> str:
    return human_responses.get_random_response('forward_to_admin')


def get_operator_request_response() -> str:
    return human_responses.get_random_response('operator_requests')


def get_error_response() -> str:
    return human_responses.get_random_response('error_responses')


def get_clarifying_question() -> str:
    return human_responses.get_random_response('clarifying_questions')


def get_booking_error_response() -> str:
    return human_responses.get_random_response('booking_errors')


def get_invalid_datetime_response() -> str:
    return human_responses.get_random_response('invalid_datetime')


def get_past_datetime_response() -> str:
    return human_responses.get_random_response('past_datetime')


def get_outside_working_hours_response(start: str = "10:00", end: str = "19:00") -> str:
    return human_responses.get_random_response('outside_working_hours', start=start, end=end)


def get_reset_success_response() -> str:
    return human_responses.get_random_response('reset_success')


def get_reset_error_response() -> str:
    return human_responses.get_random_response('reset_error')


def get_no_services_response() -> str:
    return human_responses.get_random_response('no_services')


def get_no_bookings_response() -> str:
    return human_responses.get_random_response('no_bookings')


def get_reschedule_confirmation(time: str) -> str:
    return human_responses.get_random_response('reschedule_confirmations', time=time)


def get_thanks_response() -> str:
    return human_responses.get_random_response('thanks_responses')


def get_booking_already_exists_response(time: str, service: str) -> str:
    return human_responses.get_random_response('booking_already_exists', time=time, service=service)

    """Collection of human-like response variants for different situations."""

    def __init__(self):
        # Greeting responses - warm and concise
        self.greetings = [
            "Здравствуйте! Чем могу помочь?",
            "Добрый день. Подскажу по записи или по услугам.",
            "Здравствуйте. Что вас интересует?",
            "Добрый вечер. Чем помочь?",
            "Привет! На связи, подскажу."
        ]

        # Service inquiry responses
        self.service_questions = [
            "Какая услуга вас интересует?",
            "На что хотели бы записаться?",
            "Подскажите, какая процедура нужна?",
            "Что именно вас интересует?",
            "Скажите, пожалуйста, какая услуга нужна?"
        ]

        # Name inquiry responses
        self.name_questions = [
            "Как вас зовут?",
            "Подскажите, пожалуйста, имя и фамилию.",
            "Как вас записать?",
            "Уточните имя, пожалуйста.",
            "Как к вам обращаться?"
        ]

        # Phone inquiry responses
        self.phone_questions = [
            "Подскажите номер телефона для подтверждения.",
            "Оставьте, пожалуйста, номер для связи.",
            "Какой номер лучше указать?",
            "Нужен контактный номер телефона.",
            "Пришлите, пожалуйста, номер для связи."
        ]

        # Date/time inquiry responses
        self.datetime_questions = [
            "Когда вам удобно? Например: завтра в 14:00.",
            "Подскажите дату и время, например: сегодня в 18:30.",
            "Какое время вам подойдёт?",
            "Напишите удобный день и время.",
            "Когда хотите прийти?"
        ]

        # Booking confirmation responses
        self.booking_confirmations = [
            "Готово — вы записаны на {time} ✅",
            "Запись подтверждена: {time} ✅",
            "Ждём вас {time} ✅",
            "Всё готово, запись на {time} оформлена ✅",
            "Записал вас на {time} ✅"
        ]

        # Cancellation responses
        self.cancellation_confirmations = [
            "Готово, запись на {time} отменена.",
            "Отменил запись на {time}. Если что, подберём новое время.",
            "Всё в порядке, визит на {time} отменён.",
            "Запись на {time} снял.",
            "Готово, на {time} запись отменил."
        ]

        self.no_active_booking = [
            "Сейчас у вас нет активной записи. Если хотите — могу помочь записаться заново.",
            "Сейчас активной записи нет. Если нужно, помогу оформить новую.",
            "На данный момент активной записи нет. Если захотите, подберу новое время.",
            "Пока активной записи не вижу. Если нужно, можем записаться заново.",
            "Сейчас отменять нечего. Если хотите, помогу с новой записью."
        ]

        self.cancellation_errors = [
            "Сейчас не смог отменить запись. Если хотите, попробуем ещё раз сразу здесь.",
            "Не получилось завершить отмену. Напишите ещё раз, и я помогу.",
            "С отменой не вышло с первого раза. Можем сразу повторить.",
            "Пока не удалось отменить запись. Если хотите, продолжим здесь же.",
            "Не смог сейчас подтвердить отмену. Давайте попробуем ещё раз."
        ]

        # Reschedule offer responses
        self.reschedule_offers = [
            "Сейчас у вас запись на {current_time}. Перенести на {new_time}?",
            "Вижу запись на {current_time}. Подойдёт {new_time}?",
            "Могу перенести с {current_time} на {new_time}. Подходит?",
            "Если удобно, перенесу запись на {new_time}.",
            "Предлагаю {new_time} вместо {current_time}. Подтвердить?"
        ]

        # Slot unavailable responses
        self.slot_unavailable = [
            "Это время уже занято. Могу предложить:\n\n{alternatives}",
            "Свободного окна на это время нет. Вот варианты:\n\n{alternatives}",
            "Этот слот уже занят. Посмотрите, пожалуйста:\n\n{alternatives}",
            "На это время уже есть запись. Могу предложить:\n\n{alternatives}",
            "Сейчас это время недоступно. Вот ближайшие окна:\n\n{alternatives}"
        ]

        # No alternatives available
        self.no_alternatives = [
            "Пока ближайших свободных окон не вижу.",
            "На ближайшее время всё занято.",
            "Других свободных окон пока нет.",
            "Свободных мест на ближайшие дни сейчас нет.",
            "Пока не вижу доступных вариантов рядом с этим временем."
        ]

        # Missing information responses
        self.missing_info = [
            "Нужно уточнить: {fields}.",
            "Подскажите, пожалуйста: {fields}.",
            "Мне ещё нужны {fields}.",
            "Уточните {fields}, пожалуйста.",
            "Не хватает данных: {fields}."
        ]

        # Price inquiry responses
        self.price_responses = [
            "{service} — {price} тг, примерно {duration} минут.",
            "По услуге {service}: {price} тг, длительность около {duration} минут.",
            "Стоимость {service} — {price} тг. По времени это около {duration} минут.",
            "{service} стоит {price} тг, приём занимает примерно {duration} минут.",
            "По цене: {service} — {price} тг, длительность около {duration} минут."
        ]

        # Price not available responses
        self.price_not_available = [
            "По услуге {service} стоимость лучше уточнить у администратора.",
            "Цена на {service} зависит от деталей, лучше уточнить при обращении.",
            "По {service} стоимость рассчитывается индивидуально.",
            "Точную цену на {service} подскажет администратор.",
            "По {service} цена может отличаться, лучше уточнить отдельно."
        ]

        self.price_overview = [
            "По ценам сейчас так:\n\n{items}",
            "Сориентирую по стоимости:\n\n{items}",
            "Вот кратко по ценам:\n\n{items}",
            "По прайсу на сейчас:\n\n{items}",
            "Могу подсказать так:\n\n{items}"
        ]

        self.info_missing = [
            "По {topic} сейчас не вижу точной информации в системе. Если захотите, позже уточню у администратора.",
            "Пока не подгрузились точные данные по {topic}. Если это важно, помогу уточнить.",
            "По {topic} точной информации сейчас нет. При необходимости передам вопрос администратору.",
            "Сейчас не вижу в карточке клиники данных по {topic}. Если нужно, помогу уточнить это отдельно.",
            "По {topic} пока нет точной подсказки в системе. Если захотите, вернусь с уточнением."
        ]

        # Services list responses
        self.services_list = [
            "Вот что у нас есть:\n\n{services}",
            "Доступные услуги:\n\n{services}",
            "Могу предложить такие услуги:\n\n{services}",
            "Сейчас доступны:\n\n{services}",
            "По услугам вот что есть:\n\n{services}"
        ]

        # FAQ responses
        self.faq_responses = [
            "{answer}",
            "Подсказываю: {answer}",
            "Вот информация: {answer}",
            "Да, конечно: {answer}",
            "По этому вопросу: {answer}"
        ]

        # Forward to admin responses
        self.forward_to_admin = [
            "Передал ваш вопрос администратору.",
            "Хорошо, передам это администратору.",
            "Сообщение передано, с вами свяжутся.",
            "Принял, передаю администратору.",
            "Администратор увидит ваш вопрос в ближайшее время."
        ]

        # Operator request responses
        self.operator_requests = [
            "Хорошо, передам администратору.",
            "Понял, сейчас передам ваш вопрос человеку.",
            "Сообщение отправлю администратору.",
            "Хорошо, подключим администратора.",
            "Передаю ваш вопрос администратору."
        ]

        # Error responses
        self.error_responses = [
            "Не до конца понял. Что именно нужно: запись, цена или перенос?",
            "Подскажите, пожалуйста, что вас интересует.",
            "Уточните в двух словах, чем помочь.",
            "Понял не всё. Что хотите сделать?",
            "Сориентируйте меня, пожалуйста: запись или вопрос?"
        ]

        self.booking_errors = [
            "Не получилось завершить это сразу. Давайте попробуем ещё раз.",
            "Сейчас не удалось оформить до конца. Повторите, пожалуйста.",
            "Не вышло с первого раза. Напишите ещё раз, я помогу.",
            "Давайте повторим ещё раз — всё подхвачу.",
            "Пока не получилось закончить действие. Можем сразу продолжить."
        ]

        self.clarifying_questions = [
            "Подскажите, вас интересует запись, стоимость или что-то ещё?",
            "Что именно нужно: записаться, перенести визит или задать вопрос?",
            "Чем помочь сейчас: запись, цена или информация по услугам?",
            "Уточните, пожалуйста, что для вас важно: услуга, стоимость или время?",
            "Сориентирую быстро — вам нужна запись или просто информация?"
        ]

        self.invalid_datetime = [
            "Не совсем понял дату и время. Например: завтра в 16:00.",
            "Напишите, пожалуйста, дату и время чуть точнее — например: 7 апреля в 15:30.",
            "Пока не смог разобрать время. Подойдёт формат вроде: сегодня в 18:00.",
            "Нужно чуть точнее указать время визита. Например: послезавтра в 14:00.",
            "Уточните дату и время, пожалуйста."
        ]

        self.past_datetime = [
            "Это время уже прошло. Давайте выберем другое.",
            "На прошедшее время записать не получится — подскажите будущее окно.",
            "Этот момент уже позади. Напишите, пожалуйста, другое время.",
            "Нужно выбрать время позже текущего момента.",
            "Давайте подберём ближайшее будущее время."
        ]

        self.outside_working_hours = [
            "Клиника работает с {start} до {end}. Давайте выберем время в этом диапазоне.",
            "В это время клиника уже не работает. Мы принимаем с {start} до {end}.",
            "Этот слот выходит за график. Доступное время — с {start} до {end}.",
            "Выберите, пожалуйста, время с {start} до {end}.",
            "Могу подобрать другой слот — клиника работает с {start} до {end}."
        ]

        # Reset responses
        self.reset_success = [
            "Готово. Чем помочь дальше?",
            "Всё обновил. Что вас сейчас интересует?",
            "Можно продолжать. Чем помочь?",
            "Готово, я на связи.",
            "Продолжим. Что нужно?"
        ]

        self.reset_error = [
            "Не получилось обновить диалог. Напишите ещё раз, пожалуйста.",
            "Можно просто повторить сообщение — продолжим отсюда.",
            "Если удобно, повторите запрос ещё раз.",
            "Не всё обновилось с первого раза. Давайте ещё раз.",
            "Я на связи — просто напишите запрос снова."
        ]

        # No services available
        self.no_services = [
            "Список услуг пока пуст.",
            "Пока услуги не добавлены.",
            "Сейчас список услуг ещё не заполнен.",
            "Пока не вижу добавленных услуг.",
            "Список услуг пока не готов."
        ]

        self.no_bookings = [
            "Активных записей сейчас нет.",
            "Пока записей не вижу.",
            "Сейчас у вас нет активной записи.",
            "Активных визитов пока нет.",
            "Записей на данный момент нет."
        ]

        # Reschedule confirmation responses
        self.reschedule_confirmations = [
            "Готово, перенёс запись на {time} ✅",
            "Запись перенесена на {time} ✅",
            "Теперь запись стоит на {time} ✅",
            "Есть, перенёс на {time} ✅",
            "Всё готово, новое время — {time} ✅"
        ]

    def get_random_response(self, response_type: str, **kwargs) -> str:
        """Get a random response variant for the given type."""
        responses = getattr(self, response_type, [])
        if not responses:
            return "Подскажите, пожалуйста, что вас интересует."

        response = random.choice(responses)

        # Format with provided kwargs
        try:
            return response.format(**kwargs)
        except (KeyError, ValueError):
            # If formatting fails, return unformatted response
            return response


# Global instance for easy access
human_responses = HumanResponses()


def get_greeting() -> str:
    """Get a random greeting response."""
    return human_responses.get_random_response('greetings')


def get_service_question() -> str:
    """Get a random service question."""
    return human_responses.get_random_response('service_questions')


def get_name_question() -> str:
    """Get a random name question."""
    return human_responses.get_random_response('name_questions')


def get_phone_question() -> str:
    """Get a random phone question."""
    return human_responses.get_random_response('phone_questions')


def get_datetime_question() -> str:
    """Get a random datetime question."""
    return human_responses.get_random_response('datetime_questions')


def get_booking_confirmation(time: str, service: str = "") -> str:
    """Get a random booking confirmation."""
    return human_responses.get_random_response('booking_confirmations', time=time, service=service)


def get_cancellation_confirmation(time: str, service: str = "") -> str:
    """Get a random cancellation confirmation."""
    return human_responses.get_random_response('cancellation_confirmations', time=time, service=service)


def get_no_active_booking_response() -> str:
    """Get a friendly response when there is no active booking to cancel."""
    return human_responses.get_random_response('no_active_booking')


def get_cancellation_error_response() -> str:
    """Get a friendly response when automatic cancellation fails."""
    return human_responses.get_random_response('cancellation_errors')


def get_reschedule_offer(current_time: str, new_time: str) -> str:
    """Get a random reschedule offer."""
    return human_responses.get_random_response('reschedule_offers', current_time=current_time, new_time=new_time)


def get_slot_unavailable_message(alternatives: str) -> str:
    """Get a random slot unavailable message."""
    return human_responses.get_random_response('slot_unavailable', alternatives=alternatives)


def get_no_alternatives_message() -> str:
    """Get a random no alternatives message."""
    return human_responses.get_random_response('no_alternatives')


def get_missing_info_message(fields: str) -> str:
    """Get a random missing info message."""
    return human_responses.get_random_response('missing_info', fields=fields)


def get_price_response(service: str, price: str, duration: str) -> str:
    """Get a random price response."""
    pretty_price = str(price)
    if isinstance(price, (int, float)):
        pretty_price = f"{int(price):,}".replace(",", " ")
    return human_responses.get_random_response('price_responses', service=service, price=pretty_price, duration=duration)


def get_price_not_available_response(service: str) -> str:
    """Get a random price not available response."""
    return human_responses.get_random_response('price_not_available', service=service)


def get_services_list_response(services: str) -> str:
    """Get a random services list response."""
    return human_responses.get_random_response('services_list', services=services)


def get_price_overview_response(items: str) -> str:
    """Get a short overview response for general price questions."""
    return human_responses.get_random_response('price_overview', items=items)


def get_info_missing_response(topic: str) -> str:
    """Get a graceful response when clinic info is missing."""
    return human_responses.get_random_response('info_missing', topic=topic)


def get_faq_response(answer: str) -> str:
    """Get a random FAQ response."""
    return human_responses.get_random_response('faq_responses', answer=answer)


def get_forward_to_admin_response() -> str:
    """Get a random forward to admin response."""
    return human_responses.get_random_response('forward_to_admin')


def get_operator_request_response() -> str:
    """Get a random operator request response."""
    return human_responses.get_random_response('operator_requests')


def get_error_response() -> str:
    """Get a random error response."""
    return human_responses.get_random_response('error_responses')


def get_clarifying_question() -> str:
    """Get a short clarifying question for unclear free-form messages."""
    return human_responses.get_random_response('clarifying_questions')


def get_booking_error_response() -> str:
    """Get a random booking lifecycle error response."""
    return human_responses.get_random_response('booking_errors')


def get_invalid_datetime_response() -> str:
    """Get a friendly invalid date/time response."""
    return human_responses.get_random_response('invalid_datetime')


def get_past_datetime_response() -> str:
    """Get a friendly response for past times."""
    return human_responses.get_random_response('past_datetime')


def get_outside_working_hours_response(start: str = "10:00", end: str = "19:00") -> str:
    """Get a working-hours guidance response."""
    return human_responses.get_random_response('outside_working_hours', start=start, end=end)


def get_reset_success_response() -> str:
    """Get a random reset success response."""
    return human_responses.get_random_response('reset_success')


def get_reset_error_response() -> str:
    """Get a random reset error response."""
    return human_responses.get_random_response('reset_error')


def get_no_services_response() -> str:
    """Get a random no services response."""
    return human_responses.get_random_response('no_services')


def get_no_bookings_response() -> str:
    """Get a random no bookings response."""
    return human_responses.get_random_response('no_bookings')


def get_reschedule_confirmation(time: str) -> str:
    """Get a random reschedule confirmation."""
    return human_responses.get_random_response('reschedule_confirmations', time=time)