import os
import re
import json
from datetime import datetime
import traceback

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

OPENAI_API_KEY = (os.getenv("OPENAI_API_KEY") or "").strip()
client = OpenAI(api_key=OPENAI_API_KEY) if (OPENAI_API_KEY and OpenAI is not None) else None

# Compiled greeting regex for fast detection
_GREETING_REGEX = re.compile(
    r"^("
    r"добрый?\s*(день|вечер|утр[оа]|ночи?)|"
    r"доброго\s+(утра|дня|вечера|времени(\s+суток)?)|"
    r"здравствуй(те)?|"
    r"привет(ик)?|"
    r"хай|хей|хело?|хелло?|"
    r"сал(ам)?|саламик|"
    r"добро\s+пожаловать|"
    r"рад[аы]?\s+(вас|тебя)\s+видеть|"
    r"hi|hello|hey|good\s+(morning|afternoon|evening)"
    r")[\s!,)?🤝👋]*$",
    re.IGNORECASE,
)

# Short pure greeting words
_GREETING_WORDS = {
    "привет", "здрасте", "здравствуйте", "здравствуй", "доброго",
    "добрый", "добрая", "доброе", "хай", "хей", "сал", "салам", "хело",
    "hi", "hello", "hey",
}

# Greeting and neutral message patterns (Russian and English)
GREETING_PATTERNS = [
    "привет", "здравствуйте", "здравствуй", "привет!", "привет!!", "привет)",
    "здравствуйте!", "добро пожаловать", "добрый день", "добрый вечер", "доброе утро",
    "добрый день!", "привет, как дела", "как дела", "как ваши дела", "все ли хорошо",
    "hi", "hello", "hey", "hi!", "hello!", "hey!", "what's up", "whats up",
    "привет,", "пока", "всем привет", "салам", "салам алейкум",
]

PROMPT_TEMPLATE = """
You are a strict booking data extractor for a business chatbot.

Return ONLY valid JSON.
No markdown.
No explanation.
No extra text.

Return this exact JSON structure:
{{
  "service": "",
  "full_name": "",
  "phone": "",
  "preferred_datetime": "",
  "status": "collecting",
  "next_field": "service",
  "booking_status": "in_progress",
  "intent": "booking"
}}

CRITICAL: Relative Date Parsing Rule

TODAY'S REAL DATE/TIME: {current_datetime}

All relative date expressions MUST be interpreted relative to this current date.
Do NOT invent random dates. Do NOT skip months.

Relative date rules:
- "сегодня" (today) → same as current date
- "завтра" (tomorrow) → current date + 1 day
- "послезавтра" (day after tomorrow) → current date + 2 days
- "в понедельник", "в среду" (weekday names) → NEXT occurrence of that weekday relative to current date
- If current day IS that weekday, use the same day if time is in future, otherwise next week

Examples (assuming today is 2026-03-25 Wednesday):
- "завтра в 14:00" → 2026-03-26 14:00
- "послезавтра в 10:00" → 2026-03-27 10:00
- "в пятницу в 15:00" → 2026-03-27 15:00
- "в среду в 16:00" → 2026-03-25 16:00 (today if future) or 2026-04-01 16:00 (next week if past)

Rules:

1. Detect intent:
- booking → user wants to book / continue booking / reschedule / choose time
- question → user asks about price, services, doctor/dentist name or surname, address/location, schedule, or any other clinic info
- operator → user asks to speak to human

2. If intent = "question" OR "operator":
- DO NOT erase existing fields
- Keep current memory values unless user clearly updates them
- Only change intent if needed

3. Use current memory + new message.

4. Keep existing values unless user clearly updates them.

5. Extract if present:
- service
- full_name
- phone
- preferred_datetime

6. If the user sends a generic booking message such as:
- "I want to book"
- "book me"
- "schedule me"
- "хочу записаться"
- "запишите меня"

Then:
- reset service, full_name, phone, preferred_datetime to empty strings
- set:
  status = "collecting"
  next_field = "service"
  booking_status = "in_progress"
  intent = "booking"

7. Date & time override rules - CRITICAL:

7.1 TIME-ONLY messages (user sends only time, no date):
- ALWAYS reuse the existing date from memory
- ONLY replace the time part
- Example 1: memory has "2026-03-26 14:00", user says "давай в 16:00" → result: "2026-03-26 16:00"
- Example 2: memory has "2026-03-26 14:00", user says "в 4" → result: "2026-03-26 16:00" (4 PM)
- Example 3: memory has "2026-03-26 14:00", user says "давай на 18 30" → result: "2026-03-26 18:30"
- Do NOT set next_field to preferred_datetime if memory already has a date
- Do NOT clear the date

7.2 DATE-ONLY messages (user sends only date, no time):
- ALWAYS reuse the existing time from memory
- ONLY replace the date part
- Keep the time unchanged

7.3 BOTH date and time provided:
- Replace preferred_datetime fully with new date and new time

7.4 Any new time mention (16:00, "at 4", "на 18:30"):
- ALWAYS override the old time
- But keep the old date (unless new date is also provided)

8. If multiple fields are present in one message, extract all of them.

9. Field order logic:
service → full_name → phone → preferred_datetime

10. If all fields are filled:
status = "ready_to_book"
next_field = "completed"
booking_status = "in_progress"

11. Otherwise:
status = "collecting"
next_field = first missing field
booking_status = "in_progress"

12. Output must always be valid JSON only.

Current memory:
{current_memory}

Customer message:
{user_message}
"""


def parse_user_message_fallback(user_message: str, current_state: dict) -> dict:
    """
    Fallback parser that uses simple pattern matching when AI parsing fails.
    This ensures the bot can still respond even if OpenAI is unavailable.

    Args:
        user_message: The user's message text
        current_state: Current state dictionary

    Returns:
        Dictionary with basic extracted data or unchanged state
    """
    print(f"DEBUG: Using fallback parser for message: {user_message[:100]}...")

    # Copy current state as base
    result = current_state.copy()

    message_lower = user_message.lower().strip()

    # Simple intent detection
    if any(word in message_lower for word in ["отмен", "отмени", "отмена", "удали запись", "не приду", "отменяй"]):
        result["intent"] = "cancel"
        return result

    if any(word in message_lower for word in ["перенес", "перенести", "перенос", "другое время", "изменить время"]):
        result["intent"] = "reschedule"
        return result

    question_keywords = [
        "сколько", "сколько стоит", "стоимость", "стоимости", "цена", "цену", "стоит", "прайс",
        "price", "cost", "pricing",
        "адрес", "где", "где вы", "где находитесь", "как добраться", "как вас найти", "location", "where",
        "врач", "доктор", "стоматолог", "дантист", "dentist", "doctor",
        "имя", "фамилия", "как зовут", "surname", "name",
        "график", "время работы", "режим работы", "расписание", "schedule", "hours",
        "какие услуги", "какие процедуры", "что вы делаете", "что у вас есть", "services",
        "сколько длится", "длительность"
    ]
    if any(word in message_lower for word in question_keywords) or (
        message_lower.endswith("?") and not any(word in message_lower for word in ["запис", "перенес", "отмен"])
    ):
        result["intent"] = "question"
        return result

    if any(word in message_lower for word in ["администратор", "оператор", "человек", "human", "operator"]):
        result["intent"] = "operator"
        return result

    # Simple phone number extraction (Kazakhstan format)
    import re
    phone_pattern = r'(\+7|8)?[\s\-\(]*(\d{3})[\s\-\)]*(\d{3})[\s\-]*(\d{2})[\s\-]*(\d{2})'
    phone_match = re.search(phone_pattern, user_message)
    if phone_match:
        phone = ''.join(phone_match.groups()[1:])  # Remove country code, keep digits
        result["phone"] = phone

    # Simple name extraction (words that look like names)
    words = user_message.split()
    for word in words:
        if len(word) > 2 and word[0].isupper() and not word.isdigit():
            result["full_name"] = word
            break

    # If message contains time-like patterns, try to extract datetime
    time_pattern = r'(\d{1,2})[:\.](\d{2})'
    time_match = re.search(time_pattern, user_message)
    if time_match:
        hours, minutes = time_match.groups()
        # Use current date if no date specified
        current_date = datetime.now().strftime("%Y-%m-%d")
        result["preferred_datetime"] = f"{current_date} {hours.zfill(2)}:{minutes}"

    print(f"DEBUG: Fallback parser result: {result}")
    return result


def parse_user_message(user_message: str, current_state: dict) -> dict:
    """
    Parse user message using OpenAI GPT-4.1-mini with fallback to pattern matching.
    
    Args:
        user_message: The user's message text
        current_state: Current state dictionary with booking information
        
    Returns:
        Dictionary with extracted booking data
    """
    if client is None:
        print("DEBUG: OPENAI_API_KEY is not set, using fallback parser")
        return parse_user_message_fallback(user_message, current_state)

    try:
        # Get current date and time for relative date parsing
        current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M")
        
        prompt = PROMPT_TEMPLATE.format(
            current_datetime=current_datetime,
            current_memory=json.dumps(current_state, ensure_ascii=False),
            user_message=user_message,
        )

        print(f"DEBUG: Sending to OpenAI: {user_message[:100]}...")

        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=500,
            temperature=0.1  # Low temperature for consistent parsing
        )
        
        result_text = response.choices[0].message.content.strip()
        print(f"DEBUG: OpenAI raw response: {result_text[:200]}...")
        
        # Parse JSON response
        parsed_result = json.loads(result_text)
        
        # Validate that we got the expected structure
        required_keys = ["service", "full_name", "phone", "preferred_datetime", "status", "next_field", "booking_status", "intent"]
        if not all(key in parsed_result for key in required_keys):
            print(f"ERROR: OpenAI response missing required keys: {parsed_result.keys()}")
            raise ValueError("Invalid response structure")
        
        print(f"DEBUG: Successfully parsed with OpenAI")
        return parsed_result
        
    except json.JSONDecodeError as e:
        print(f"ERROR: Failed to parse OpenAI JSON response: {e}")
        traceback.print_exc()
    except Exception as e:
        print(f"ERROR: OpenAI parsing failed: {repr(e)}")
        traceback.print_exc()
    
    # Fallback to pattern matching if AI parsing fails
    print("DEBUG: Falling back to pattern matching parser")
    return parse_user_message_fallback(user_message, current_state)


def is_greeting_message(user_message: str) -> bool:
    """
    Detect if a message is a neutral greeting or small-talk. Supports broad
    natural Russian phrasing, not just exact phrase matching.

    Returns True if message is a greeting (not a booking/question/action request).
    """
    msg = (user_message or "").strip()
    if not msg:
        return False

    # Compiled regex covers the most common patterns quickly
    if _GREETING_REGEX.match(msg):
        return True

    msg_low = msg.lower().replace("ё", "е")

    # Exact matches from legacy list
    for pattern in GREETING_PATTERNS:
        if msg_low == pattern:
            return True

    # Short messages (1-3 words) whose first word is a known greeting word
    words = msg_low.split()
    if 1 <= len(words) <= 3 and words[0] in _GREETING_WORDS:
        return True

    return False
